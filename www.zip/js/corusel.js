$(function() {
    $('.rotating-slider').rotatingSlider({
        slideHeight : 320,
        slideWidth : 300,
        autoRotate: true, 
        autoRotateInterva: 1000
    });
})